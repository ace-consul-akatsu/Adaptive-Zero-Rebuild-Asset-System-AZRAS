from __future__ import annotations

import csv
import json
import math
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from comparison.extractor import extract_core_project

ROOT = Path(__file__).resolve().parent

METRICS = {
    "environment": [
        ("annual_energy_kwh", "年間エネルギー", "Annual Energy", "kWh", "min"),
        ("annual_operation_co2_kg", "年間運用CO₂", "Annual Operational CO₂", "kg-CO₂", "min"),
        ("lifecycle_co2_kg", "ライフサイクルCO₂", "Life-Cycle CO₂", "kg-CO₂", "min"),
        ("annual_pv_generation_kwh", "年間PV発電量", "Annual PV Generation", "kWh", "max"),
        ("environment_score", "地域環境適合点", "Regional Environmental Score", "点", "max"),
    ],
    "cost": [
        ("construction_cost_jpy", "建設費", "Construction Cost", "JPY", "min"),
        ("maintenance_total_jpy", "修繕・更新・解体費", "Repair/Renewal/Demolition Cost", "JPY", "min"),
    ],
    "business": [
        ("npv_200_jpy", "200年NPV", "200-Year NPV", "JPY", "max"),
        ("irr_200_percent", "200年IRR", "200-Year IRR", "%", "max"),
        ("net_cashflow_200_jpy", "200年純キャッシュフロー", "200-Year Net Cash Flow", "JPY", "max"),
    ],
    "suitability": [
        ("suitability_score", "地域総合適合点", "Regional Suitability Score", "点", "max"),
        ("resilience_score", "災害適応性", "Resilience", "点", "max"),
        ("climate_fit_score", "気候適合性", "Climate Fit", "点", "max"),
        ("durability_score", "耐久性", "Durability", "点", "max"),
        ("availability_score", "材料・施工性", "Local Availability", "点", "max"),
        ("legal_score", "法規確認度", "Legal Readiness", "点", "max"),
        ("data_confidence_score", "データ信頼度", "Data Confidence", "点", "max"),
    ],
}


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.language = tk.StringVar(value="ja")
        self.paths = [tk.StringVar() for _ in range(7)]
        self.projects = []
        self.location_key = tk.StringVar()
        self.weights = {
            "environment": tk.DoubleVar(value=40),
            "cost": tk.DoubleVar(value=20),
            "business": tk.DoubleVar(value=25),
            "suitability": tk.DoubleVar(value=15),
        }
        self.title("AZRAS Integrated_Comparison v2.0")
        self.geometry("1560x940")
        self.minsize(1240, 760)
        self.build()
        self.apply_language()

    def t(self, key):
        ja = {
            "title":"AZRAS Integrated_Comparison v2.0",
            "subtitle":"地域ごとに最も環境的・経済的・事業的に優れた工法を判定",
            "language":"言語","new":"新規","load":"比較設定読込","save":"比較設定保存","csv":"結果CSV保存",
            "select":"Core JSON選択","clear":"解除","compare":"Core JSONを読込・比較","slot":"工法 {n}",
            "location":"評価地域","weights":"総合評価の重み（合計100%）","environment":"環境","cost":"コスト","business":"事業性","suitability":"地域適合性",
            "ranking":"地域別工法ランキング","method":"工法","project":"プロジェクト","overall":"総合点","recommendation":"判定","blockers":"要確認条件",
            "details":"詳細比較","item":"比較項目","unit":"単位","winner":"最優秀","ready":"Core v3.2のProject JSONを2～7件選択してください。各JSONは単一工法です。",
            "need_two":"2件以上のCore JSONを選択してください。","no_common":"共通する追加地域がありません。基本地域名を揃えるか、Module 9で同じ都市を登録してください。",
            "regional_cost_note":"地域別の建設費・事業収支はCore側で未計算の場合、基本地域の値を参考表示し、ランキング点から除外します。",
            "loaded":"{count}工法を読み込みました。","error":"エラー","saved":"保存しました。",
        }
        en = {
            "title":"AZRAS Integrated_Comparison v2.0",
            "subtitle":"Identify the most environmentally, economically and commercially suitable method for each region",
            "language":"Language","new":"New","load":"Load Set","save":"Save Set","csv":"Export Results CSV",
            "select":"Select Core JSON","clear":"Clear","compare":"Load and Compare","slot":"Method {n}",
            "location":"Assessment Region","weights":"Overall Weights (Total 100%)","environment":"Environment","cost":"Cost","business":"Business","suitability":"Regional Suitability",
            "ranking":"Regional Method Ranking","method":"Method","project":"Project","overall":"Overall","recommendation":"Recommendation","blockers":"Conditions / Blockers",
            "details":"Detailed Comparison","item":"Metric","unit":"Unit","winner":"Best","ready":"Select 2–7 Core v3.2 Project JSON files. Each JSON represents one method.",
            "need_two":"Select at least two Core JSON files.","no_common":"No common regional locations were found.",
            "regional_cost_note":"If regional cost and business results are not calculated in Core, base-location values are shown for reference and excluded from regional ranking.",
            "loaded":"Loaded {count} methods.","error":"Error","saved":"Saved.",
        }
        return (ja if self.language.get()=="ja" else en).get(key,key)

    def build(self):
        top=ttk.Frame(self);top.pack(fill="x",padx=14,pady=(10,4))
        self.lang_label=ttk.Label(top);self.lang_label.pack(side="left")
        combo=ttk.Combobox(top,textvariable=self.language,values=("ja","en"),state="readonly",width=8)
        combo.pack(side="left",padx=4);combo.bind("<<ComboboxSelected>>",lambda e:self.apply_language())
        self.csv_btn=ttk.Button(top,command=self.export_csv);self.csv_btn.pack(side="right",padx=3)
        self.save_btn=ttk.Button(top,command=self.save_set);self.save_btn.pack(side="right",padx=3)
        self.load_btn=ttk.Button(top,command=self.load_set);self.load_btn.pack(side="right",padx=3)
        self.new_btn=ttk.Button(top,command=self.new_set);self.new_btn.pack(side="right",padx=3)
        self.title_lbl=ttk.Label(self,font=("Yu Gothic UI",23,"bold"),anchor="center");self.title_lbl.pack(fill="x")
        self.subtitle_lbl=ttk.Label(self,font=("Yu Gothic UI",11),anchor="center");self.subtitle_lbl.pack(fill="x",pady=(1,7))

        inp=ttk.LabelFrame(self,text="Core Project JSON");inp.pack(fill="x",padx=16,pady=4)
        self.slot_labels=[];self.select_buttons=[];self.clear_buttons=[]
        for i,var in enumerate(self.paths):
            lab=ttk.Label(inp,width=11);lab.grid(row=i,column=0,padx=4,pady=2,sticky="e")
            ttk.Entry(inp,textvariable=var,state="readonly").grid(row=i,column=1,padx=4,pady=2,sticky="ew")
            b=ttk.Button(inp,command=lambda n=i:self.select_json(n));b.grid(row=i,column=2,padx=3)
            c=ttk.Button(inp,command=lambda n=i:self.clear_json(n));c.grid(row=i,column=3,padx=3)
            self.slot_labels.append(lab);self.select_buttons.append(b);self.clear_buttons.append(c)
        inp.columnconfigure(1,weight=1)
        self.compare_btn=ttk.Button(inp,command=self.compare);self.compare_btn.grid(row=7,column=0,columnspan=4,pady=6)

        controls=ttk.Frame(self);controls.pack(fill="x",padx=16,pady=4)
        self.location_label=ttk.Label(controls);self.location_label.pack(side="left")
        self.location_combo=ttk.Combobox(controls,textvariable=self.location_key,state="readonly",width=34)
        self.location_combo.pack(side="left",padx=5);self.location_combo.bind("<<ComboboxSelected>>",lambda e:self.refresh_results())
        self.weight_frame=ttk.LabelFrame(controls);self.weight_frame.pack(side="left",padx=16)
        self.weight_labels={}
        for key,var in self.weights.items():
            lab=ttk.Label(self.weight_frame);lab.pack(side="left",padx=(7,2));self.weight_labels[key]=lab
            sp=ttk.Spinbox(self.weight_frame,from_=0,to=100,textvariable=var,width=5,command=self.refresh_results)
            sp.pack(side="left",padx=(0,3));sp.bind("<FocusOut>",lambda e:self.refresh_results())
        self.note=ttk.Label(self,foreground="#8b0000",wraplength=1500);self.note.pack(fill="x",padx=18,pady=3)

        tabs=ttk.Notebook(self);tabs.pack(fill="both",expand=True,padx=14,pady=5)
        rank_frame=ttk.Frame(tabs);detail_frame=ttk.Frame(tabs)
        tabs.add(rank_frame,text="Ranking");tabs.add(detail_frame,text="Details")
        cols=("rank","method","project","overall","environment","cost","business","suitability","recommendation","blockers")
        self.rank_tree=ttk.Treeview(rank_frame,columns=cols,show="headings")
        widths={"rank":55,"method":170,"project":210,"overall":85,"environment":90,"cost":90,"business":90,"suitability":95,"recommendation":120,"blockers":420}
        for c in cols:self.rank_tree.column(c,width=widths[c],anchor="center" if c not in ("method","project","blockers") else "w")
        self.rank_tree.pack(fill="both",expand=True)
        self.rank_tree.bind("<<TreeviewSelect>>",lambda e:self.draw_radar())
        lower=ttk.Panedwindow(rank_frame,orient="horizontal");lower.pack(fill="x",pady=4)
        self.radar=tk.Canvas(lower,height=290,bg="white");self.info=tk.Text(lower,height=12,wrap="word")
        lower.add(self.radar,weight=2);lower.add(self.info,weight=3)

        dcols=("item","unit","winner")+tuple(f"p{i}" for i in range(7))
        self.detail_tree=ttk.Treeview(detail_frame,columns=dcols,show="headings")
        self.detail_tree.column("item",width=260);self.detail_tree.column("unit",width=85);self.detail_tree.column("winner",width=130)
        for i in range(7):self.detail_tree.column(f"p{i}",width=160)
        self.detail_tree.pack(fill="both",expand=True)
        self.status=ttk.Label(self,anchor="w");self.status.pack(fill="x",padx=16,pady=(0,8))

    def apply_language(self):
        self.title(self.t("title"));self.title_lbl.config(text=self.t("title"));self.subtitle_lbl.config(text=self.t("subtitle"));self.lang_label.config(text=self.t("language"))
        self.new_btn.config(text=self.t("new"));self.load_btn.config(text=self.t("load"));self.save_btn.config(text=self.t("save"));self.csv_btn.config(text=self.t("csv"));self.compare_btn.config(text=self.t("compare"))
        self.location_label.config(text=self.t("location"));self.weight_frame.config(text=self.t("weights"));self.note.config(text=self.t("regional_cost_note"));self.status.config(text=self.t("ready"))
        for i in range(7):self.slot_labels[i].config(text=self.t("slot").format(n=i+1));self.select_buttons[i].config(text=self.t("select"));self.clear_buttons[i].config(text=self.t("clear"))
        for k,l in self.weight_labels.items():l.config(text=self.t(k))
        heads={"rank":"No.","method":self.t("method"),"project":self.t("project"),"overall":self.t("overall"),"environment":self.t("environment"),"cost":self.t("cost"),"business":self.t("business"),"suitability":self.t("suitability"),"recommendation":self.t("recommendation"),"blockers":self.t("blockers")}
        for c,h in heads.items():self.rank_tree.heading(c,text=h)
        self.detail_tree.heading("item",text=self.t("item"));self.detail_tree.heading("unit",text=self.t("unit"));self.detail_tree.heading("winner",text=self.t("winner"))
        self.refresh_results()

    def select_json(self,i):
        p=filedialog.askopenfilename(parent=self,filetypes=[("Core Project JSON","*.json"),("All files","*.*")])
        if p:self.paths[i].set(p)
    def clear_json(self,i):self.paths[i].set("")
    def new_set(self):
        for v in self.paths:v.set("")
        self.projects=[];self.location_combo.config(values=[]);self.location_key.set("");self.clear_views()
    def compare(self):
        paths=[v.get() for v in self.paths if v.get()]
        if len(paths)<2:messagebox.showwarning(self.t("error"),self.t("need_two"),parent=self);return
        try:self.projects=[extract_core_project(p) for p in paths]
        except Exception as e:messagebox.showerror(self.t("error"),str(e),parent=self);return
        maps=[]
        for p in self.projects:maps.append({x["key"]:x for x in p["locations"]})
        common=set(maps[0])
        for m in maps[1:]:common &= set(m)
        # Base location can be compared even if names differ only when all base locations are present.
        ordered=[]
        if "__base__" in common:ordered.append("__base__")
        ordered += sorted(k for k in common if k!="__base__")
        if not ordered:messagebox.showwarning(self.t("error"),self.t("no_common"),parent=self);return
        labels=[]
        for k in ordered:
            if k=="__base__":labels.append((k,"基本地域 / Base Location"))
            else:
                row=next(m[k] for m in maps if k in m);labels.append((k,f'{row.get("name")} / {row.get("country")}'))
        self.location_combo.config(values=[x[1] for x in labels]);self.location_combo._keymap={v:k for k,v in labels};self.location_key.set(labels[0][1])
        self.status.config(text=self.t("loaded").format(count=len(self.projects)));self.refresh_results()

    def selected_location(self):
        display=self.location_key.get();key=getattr(self.location_combo,"_keymap",{}).get(display)
        rows=[]
        if key is None:return rows
        for p in self.projects:
            loc=next((x for x in p["locations"] if x["key"]==key),None)
            if loc:rows.append((p,loc))
        return rows

    def normalized_group(self, rows, metric_defs):
        metric_scores={}
        for key,ja,en,unit,direction in metric_defs:
            vals=[r[1].get(key) for r in rows]
            nums=[float(v) for v in vals if isinstance(v,(int,float))]
            if len(nums)<2 or max(nums)==min(nums):
                for i,v in enumerate(vals):metric_scores.setdefault(i,[]).append(50.0 if isinstance(v,(int,float)) else None)
                continue
            lo,hi=min(nums),max(nums)
            for i,v in enumerate(vals):
                if not isinstance(v,(int,float)):score=None
                elif direction=="min":score=100*(hi-v)/(hi-lo)
                else:score=100*(v-lo)/(hi-lo)
                metric_scores.setdefault(i,[]).append(score)
        out=[]
        for i in range(len(rows)):
            valid=[x for x in metric_scores.get(i,[]) if x is not None]
            out.append(sum(valid)/len(valid) if valid else None)
        return out

    def compute_ranking(self):
        rows=self.selected_location();groups={k:self.normalized_group(rows,v) for k,v in METRICS.items()}
        w={k:max(0,float(v.get())) for k,v in self.weights.items()};total=sum(w.values()) or 1
        result=[]
        for i,(p,loc) in enumerate(rows):
            available=[];weighted=0
            for g in groups:
                s=groups[g][i]
                # Regional cost/business from base values are reference only for additional locations.
                if not loc.get("is_base") and g in ("cost","business"):
                    s=None
                if s is not None:
                    weighted += s*w[g];available.append(w[g])
            overall=weighted/(sum(available) or 1)
            recommendation=loc.get("recommendation") or ("reference" if loc.get("is_base") else "")
            result.append({"project":p,"location":loc,"scores":{g:groups[g][i] for g in groups},"overall":overall,"recommendation":recommendation})
        result.sort(key=lambda x:x["overall"],reverse=True)
        return result

    def refresh_results(self):
        self.clear_views()
        if not self.projects or not self.location_key.get():return
        ranking=self.compute_ranking();self._ranking=ranking
        for n,r in enumerate(ranking,1):
            p,l=r["project"],r["location"];s=r["scores"]
            fmt=lambda x:"-" if x is None else f"{x:.1f}"
            self.rank_tree.insert("","end",iid=str(n-1),values=(n,p["method_label"]+(f' ({p["method_detail"]})' if p["method_detail"] else ""),p["project_name"],f'{r["overall"]:.1f}',fmt(s["environment"]),fmt(s["cost"]),fmt(s["business"]),fmt(s["suitability"]),r["recommendation"],", ".join(l.get("blockers") or [])))
        self.fill_details();
        if ranking:self.rank_tree.selection_set("0");self.draw_radar()

    def clear_views(self):
        for tree in (self.rank_tree,self.detail_tree):
            for x in tree.get_children():tree.delete(x)
        self.radar.delete("all");self.info.delete("1.0","end")

    def fill_details(self):
        rows=self.selected_location();headers=[]
        for i in range(7):
            text=rows[i][0]["method_label"] if i<len(rows) else ""
            self.detail_tree.heading(f"p{i}",text=text)
        for group,defs in METRICS.items():
            for key,ja,en,unit,direction in defs:
                vals=[loc.get(key) for p,loc in rows];valid=[(i,v) for i,v in enumerate(vals) if isinstance(v,(int,float))]
                winner="-"
                if valid:
                    wi=(min(valid,key=lambda x:x[1]) if direction=="min" else max(valid,key=lambda x:x[1]))[0]
                    winner=rows[wi][0]["method_label"]
                display=[]
                for v in vals:
                    if v is None:display.append("-")
                    elif unit=="JPY":display.append(f"¥{v:,.0f}")
                    else:display.append(f"{v:,.2f}")
                display += [""]*(7-len(display))
                self.detail_tree.insert("","end",values=((ja if self.language.get()=="ja" else en),unit,winner,*display))

    def draw_radar(self):
        sel=self.rank_tree.selection();
        if not sel:return
        r=self._ranking[int(sel[0])];axes=[("environment",self.t("environment")),("cost",self.t("cost")),("business",self.t("business")),("suitability",self.t("suitability"))]
        c=self.radar;c.delete("all");c.update_idletasks();w=max(c.winfo_width(),400);h=max(c.winfo_height(),260);cx=w*0.35;cy=h*0.52;rad=min(w,h)*0.31;n=len(axes)
        for lev in range(1,6):
            pts=[]
            for i in range(n):a=-math.pi/2+2*math.pi*i/n;rr=rad*lev/5;pts.extend((cx+rr*math.cos(a),cy+rr*math.sin(a)))
            c.create_polygon(pts,outline="#cccccc",fill="")
        pts=[]
        for i,(k,label) in enumerate(axes):
            a=-math.pi/2+2*math.pi*i/n;c.create_line(cx,cy,cx+rad*math.cos(a),cy+rad*math.sin(a),fill="#bbbbbb");c.create_text(cx+(rad+28)*math.cos(a),cy+(rad+28)*math.sin(a),text=label)
            score=r["scores"].get(k);score=0 if score is None else score;rr=rad*score/100;pts.extend((cx+rr*math.cos(a),cy+rr*math.sin(a)))
        c.create_polygon(pts,outline="#333333",fill="#dddddd",stipple="gray50",width=2)
        self.info.delete("1.0","end");p,l=r["project"],r["location"]
        self.info.insert("1.0",f'{p["method_label"]}\n{p["project_name"]}\n\n総合点 / Overall: {r["overall"]:.1f}\n判定 / Recommendation: {r["recommendation"]}\n要確認 / Blockers: {", ".join(l.get("blockers") or ["-"])}\n\n地域別コスト・事業性がCoreで未計算の場合、それらは総合点から除外されます。')

    def save_set(self):
        p=filedialog.asksaveasfilename(parent=self,defaultextension=".json",filetypes=[("Comparison Set","*.json")])
        if p:Path(p).write_text(json.dumps({"version":"2.0","paths":[v.get() for v in self.paths],"weights":{k:v.get() for k,v in self.weights.items()}},ensure_ascii=False,indent=2),encoding="utf-8");messagebox.showinfo(self.t("save"),self.t("saved"),parent=self)
    def load_set(self):
        p=filedialog.askopenfilename(parent=self,filetypes=[("Comparison Set","*.json")]);
        if not p:return
        d=json.loads(Path(p).read_text(encoding="utf-8"));
        for i,v in enumerate(d.get("paths",[])[:7]):self.paths[i].set(v)
        for k,v in (d.get("weights") or {}).items():
            if k in self.weights:self.weights[k].set(v)
    def export_csv(self):
        if not hasattr(self,"_ranking") or not self._ranking:return
        p=filedialog.asksaveasfilename(parent=self,defaultextension=".csv",filetypes=[("CSV","*.csv")],initialfile="Integrated_Comparison_Regional_Ranking.csv")
        if not p:return
        with open(p,"w",newline="",encoding="utf-8-sig") as f:
            w=csv.writer(f);w.writerow(["rank","method","project","location","overall","environment","cost","business","suitability","recommendation","blockers"])
            for i,r in enumerate(self._ranking,1):w.writerow([i,r["project"]["method_label"],r["project"]["project_name"],r["location"]["name"],r["overall"],r["scores"]["environment"],r["scores"]["cost"],r["scores"]["business"],r["scores"]["suitability"],r["recommendation"],";".join(r["location"].get("blockers") or [])])
        messagebox.showinfo(self.t("csv"),self.t("saved"),parent=self)

if __name__=="__main__":App().mainloop()
