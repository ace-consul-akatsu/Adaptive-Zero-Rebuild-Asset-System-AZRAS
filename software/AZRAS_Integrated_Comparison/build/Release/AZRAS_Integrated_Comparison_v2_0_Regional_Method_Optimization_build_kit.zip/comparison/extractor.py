from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def _f(value: Any, default=None):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _first(*values):
    for value in values:
        if value not in (None, "", [], {}):
            return value
    return None


def _find_number(obj: Any, keys: tuple[str, ...]):
    wanted = {str(k).lower() for k in keys}
    def walk(value):
        if isinstance(value, dict):
            for k, v in value.items():
                if str(k).lower() in wanted:
                    n = _f(v)
                    if n is not None:
                        return n
            for v in value.values():
                result = walk(v)
                if result is not None:
                    return result
        elif isinstance(value, list):
            for v in value:
                result = walk(v)
                if result is not None:
                    return result
        return None
    return walk(obj)


def _method(project: dict[str, Any]) -> tuple[str, str, str]:
    common = project.get("common") or {}
    detailed = common.get("detailed_configuration") or {}
    system = detailed.get("building_system") or "general"
    if system == "azras":
        a = detailed.get("azras") or {}
        core = a.get("core_structure", "")
        infill = a.get("infill_structure", "")
        method = a.get("infill_method", "")
        label = "AZRAS"
        detail = " / ".join(x for x in (core, infill, method) if x)
        return label, detail, "azras"
    g = detailed.get("general") or {}
    structure = str(g.get("structure") or common.get("construction_method_name_ja") or "")
    method = str(g.get("method") or "")
    label = structure or method or "Unknown"
    detail = method
    return label, detail, structure or "other"


def _base_location(project: dict[str, Any]) -> dict[str, Any]:
    common = project.get("common") or {}
    loc = common.get("location") or {}
    return {
        "key": "__base__",
        "name": str(common.get("city") or loc.get("city") or "Base Location"),
        "country": str(common.get("country") or loc.get("country") or ""),
        "latitude": _first(common.get("latitude"), loc.get("latitude")),
        "longitude": _first(common.get("longitude"), loc.get("longitude")),
        "is_base": True,
    }


def _base_metrics(project: dict[str, Any]) -> dict[str, Any]:
    common = project.get("common") or {}
    building = common.get("building") or {}
    renewable = common.get("renewable_energy") or {}
    outputs = project.get("module_outputs") or {}
    m1 = outputs.get("module1") or {}
    m2 = outputs.get("module2") or {}
    m4 = outputs.get("module4") or {}
    m5 = outputs.get("module5") or {}
    m7 = outputs.get("module7") or {}
    m8 = outputs.get("module8") or {}
    scale = m1.get("building_scale") or {}
    gfa = _first(common.get("scale_gfa_m2"), building.get("gross_floor_area_m2"), scale.get("gross_floor_area_m2"))
    return {
        "gross_floor_area_m2": _f(gfa),
        "annual_energy_kwh": _find_number(m2, ("annual_total_energy_kWh", "annual_energy_kwh", "annual_primary_energy_kwh")),
        "annual_heating_kwh": _find_number(m2, ("annual_heating_energy_kWh", "heating_energy_kwh")),
        "annual_cooling_kwh": _find_number(m2, ("annual_cooling_energy_kWh", "cooling_energy_kwh")),
        "annual_pv_generation_kwh": _first(_f(renewable.get("annual_generation_kWh")), _find_number(m2, ("annual_pv_generation_kwh", "pv_generation_kwh"))),
        "annual_operation_co2_kg": _find_number(m2, ("annual_operational_co2_kg", "annual_operation_co2_kg")),
        "lifecycle_co2_kg": _find_number(m4, ("lifecycle_total_co2_kg", "life_cycle_total_co2_kg", "ライフサイクル純co2", "総co2")),
        "lifecycle_energy_mj": _find_number(m4, ("lifecycle_total_energy_mj", "total_energy_mj", "ライフサイクル総エネルギー")),
        "construction_cost_jpy": _find_number(m5, ("tax_included_construction_cost", "total_construction_cost", "tax_excluded_construction_cost", "税込建設費", "税抜建設費")),
        "maintenance_total_jpy": _find_number(m7, ("repair_renewal_demolition_total", "total_cost", "修繕・更新・解体・再建費総額")),
        "npv_200_jpy": _find_number(m8, ("npv", "200年npv")),
        "irr_200_percent": _find_number(m8, ("irr_percent", "200年irr")),
        "net_cashflow_200_jpy": _find_number(m8, ("net_cashflow_total", "累積純キャッシュフロー")),
        "data_source": "core_module_results",
    }


def _regional_metrics(project: dict[str, Any], row: dict[str, Any], base: dict[str, Any]) -> dict[str, Any]:
    result = row.get("result") or {}
    axes = result.get("axes") or {}
    # Core v3.2 stores suitability. Location energy may be present from batch output.
    batch = project.get("batch_location_analysis") or {}
    batch_loc = batch.get("location") or {}
    batch_analysis = batch.get("location_analysis") or {}
    same_batch_location = (
        str(batch_loc.get("city") or batch_loc.get("name") or "").lower()
        == str(row.get("name") or row.get("ja") or "").lower()
    )
    energy = {}
    if same_batch_location:
        energy = {
            "annual_heating_kwh": _f(batch_analysis.get("estimated_annual_heating_energy_kWh")),
            "annual_cooling_kwh": _f(batch_analysis.get("estimated_annual_cooling_energy_kWh")),
            "annual_pv_generation_kwh": _f(batch_analysis.get("estimated_annual_pv_generation_kWh")),
            "data_source": "batch_ai_estimate",
        }
        vals = [energy.get("annual_heating_kwh"), energy.get("annual_cooling_kwh")]
        if all(v is not None for v in vals):
            energy["annual_energy_kwh"] = sum(vals)
    return {
        **base,
        **energy,
        "suitability_score": _f(result.get("overall_score")),
        "recommendation": result.get("recommendation", ""),
        "environment_score": _f(axes.get("environment")),
        "resilience_score": _f(axes.get("resilience")),
        "climate_fit_score": _f(axes.get("climate_fit")),
        "durability_score": _f(axes.get("durability")),
        "availability_score": _f(axes.get("local_availability")),
        "legal_score": _f(axes.get("legal_readiness")),
        "data_confidence_score": _f(axes.get("data_confidence")),
        "blockers": result.get("blockers") or [],
        "regional_cost_status": "not_calculated_in_core",
        "regional_business_status": "not_calculated_in_core",
    }


def extract_core_project(path: str | Path) -> dict[str, Any]:
    path = Path(path)
    project = json.loads(path.read_text(encoding="utf-8"))
    common = project.get("common") or {}
    label, detail, method_key = _method(project)
    base_location = _base_location(project)
    base_metrics = _base_metrics(project)
    base_result = {
        **base_location,
        **base_metrics,
        "suitability_score": None,
        "recommendation": "base_location",
        "environment_score": None,
        "resilience_score": None,
        "climate_fit_score": None,
        "durability_score": None,
        "availability_score": None,
        "legal_score": None,
        "data_confidence_score": None,
        "blockers": [],
    }
    locations = [base_result]
    regional = project.get("regional_analysis") or {}
    for row in regional.get("additional_locations") or []:
        if not row.get("enabled", True):
            continue
        location = {
            "key": str(row.get("name") or row.get("ja") or "").lower(),
            "name": str(row.get("ja") or row.get("name") or ""),
            "country": str(row.get("country") or ""),
            "latitude": row.get("latitude"),
            "longitude": row.get("longitude"),
            "is_base": False,
        }
        locations.append({**location, **_regional_metrics(project, row, base_metrics)})
    return {
        "source_path": str(path),
        "project_name": str(common.get("project_name") or path.stem),
        "method_label": label,
        "method_detail": detail,
        "method_key": method_key,
        "analysis_mode": common.get("analysis_mode", "lite"),
        "locations": locations,
        "base_metrics": base_metrics,
    }
