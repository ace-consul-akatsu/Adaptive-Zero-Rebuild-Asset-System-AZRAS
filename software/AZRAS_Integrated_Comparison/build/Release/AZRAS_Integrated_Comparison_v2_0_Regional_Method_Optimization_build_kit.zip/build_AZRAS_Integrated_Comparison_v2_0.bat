@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
set "ROOT=%~dp0"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"
set "LOG=%ROOT%\AZRAS_Integrated_Comparison_v2_0_build_log.txt"
set "DIST=%ROOT%\dist_AZRAS_Integrated_Comparison_v2_0"
set "BUILD=%ROOT%\build_AZRAS_Integrated_Comparison_v2_0"
set "EXE=%DIST%\AZRAS_Integrated_Comparison_v2_0.exe"
> "%LOG%" echo AZRAS Integrated_Comparison v2.0 Build Log
taskkill /F /IM AZRAS_Integrated_Comparison_v2_0.exe >>"%LOG%" 2>&1
if exist "%BUILD%" rmdir /S /Q "%BUILD%"
if exist "%DIST%" rmdir /S /Q "%DIST%"
mkdir "%BUILD%"
mkdir "%DIST%"
python -m pip install --upgrade pyinstaller >>"%LOG%" 2>&1
if errorlevel 1 goto FAILED
python -m PyInstaller --noconfirm --clean --windowed --onefile ^
 --name AZRAS_Integrated_Comparison_v2_0 ^
 --distpath "%DIST%" ^
 --workpath "%BUILD%" ^
 "%ROOT%\main.py" >>"%LOG%" 2>&1
if errorlevel 1 goto FAILED
if not exist "%EXE%" goto FAILED
explorer /select,"%EXE%"
pause
exit /b 0
:FAILED
echo Build failed. Check:
echo %LOG%
pause
exit /b 1
